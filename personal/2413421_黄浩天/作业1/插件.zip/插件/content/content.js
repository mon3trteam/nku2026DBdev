/* =============================================================================
 * 南开选课助手 · content script
 *  - 多功能搜索：升级自控制台脚本（Jquery.txt 思路）：
 *      .electGridTr 行扫描 + .stdCount 余量判断 + .pgNextBtn 自动翻页
 *      扩展为：多关键字(与/或)、教师/校区过滤、只看有余量、全页扫描进度、
 *              高亮、结果定位、CSV 导出、一键加入抢课队列
 *  - 自动化发包：移植自 exe 抢课客户端 (grabber.py) 的浏览器化版本：
 *      同源 fetch 自动携带已登录 Cookie（无需账号密码/cookies.json），
 *      保留预热、返回分类、混合/优先/蹲点三种模式、间隔+抖动、会话失效提醒。
 * ============================================================================= */
(() => {
  'use strict';
  if (window.__NKU_ELECT_HELPER__) return;
  window.__NKU_ELECT_HELPER__ = true;

  /* ============================ 基础工具 ============================ */
  const BASE = location.origin;
  const IS_ELECT_PAGE = /stdElectCourse/i.test(location.href);

  const qs = (s, r = document) => r.querySelector(s);
  const qsa = (s, r = document) => Array.from(r.querySelectorAll(s));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const escRx = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const fmtTime = (d = new Date()) => d.toTimeString().slice(0, 8);
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null) continue;
      if (k === 'style') node.style.cssText = v;
      else if (k === 'class') node.className = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2).toLowerCase(), v);
      else node.setAttribute(k, v);
    }
    for (const c of children.flat(Infinity)) {
      if (c == null || c === false) continue;
      node.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return node;
  }

  /* 带降级的存储（chrome.storage 不可用时退回 localStorage） */
  const store = {
    async get(keys, def) {
      try {
        const o = await chrome.storage.local.get(keys);
        return o;
      } catch (e) {
        const out = {};
        for (const k of [].concat(keys)) {
          const v = localStorage.getItem('nkusize_' + k);
          out[k] = v ? JSON.parse(v) : def[k];
        }
        return out;
      }
    },
    async set(obj) {
      try {
        await chrome.storage.local.set(obj);
      } catch (e) {
        for (const [k, v] of Object.entries(obj)) {
          try { localStorage.setItem('nkusize_' + k, JSON.stringify(v)); } catch (_) {}
        }
      }
    },
  };

  /* ============================ 设置 ============================ */
  const DEFAULT_SETTINGS = {
    intervalMs: 520,        // 发包间隔（毫秒）
    jitterMs: 120,          // 随机抖动（毫秒），0 为关闭
    mode: 'mixed',          // mixed 混合轮询 | priority 优先 | stakeout 蹲点
    sound: true,            // 成功提示音
    notifyOnSuccess: true,  // 成功桌面通知
    webhook: '',            // 可选 webhook 推送
    searchOnlyAvailable: true,
    searchLogic: 'or',      // or 任一关键字命中 | and 全部命中
    searchMaxPages: 0,      // 0 = 扫描全部页
  };
  let settings = { ...DEFAULT_SETTINGS };

  /* ============================ 日志 ============================ */
  const Log = {
    items: [],
    MAX: 500,
    add(level, msg) {
      this.items.push({ t: fmtTime(), level, msg: String(msg) });
      if (this.items.length > this.MAX) this.items.shift();
      try { console.log('[选课助手][' + level + ']', msg); } catch (_) {}
      if (UI.logBox) this.render();
    },
    render() {
      if (!UI.logBox) return;
      UI.logBox.innerHTML = '';
      for (const it of [...this.items].reverse()) {
        UI.logBox.append(el('div', { class: 'nku-logline nku-log-' + it.level }, `[${it.t}] ${it.msg}`));
      }
    },
    clear() { this.items = []; this.render(); },
    text() { return this.items.map((i) => `[${i.t}][${i.level}] ${i.msg}`).join('\n'); },
  };

  /* ============================ 提醒 ============================ */
  function notify(title, message) {
    if (!settings.notifyOnSuccess && !/失效/.test(title)) return;
    try { chrome.runtime.sendMessage({ type: 'ext-notify', title, message }); } catch (_) {}
  }

  function beep(times = 3) {
    if (!settings.sound) return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      beep._ctx = beep._ctx || new Ctx();
      const ctx = beep._ctx;
      if (ctx.state === 'suspended') ctx.resume();
      let t = ctx.currentTime + 0.03;
      for (let i = 0; i < times; i++) {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.value = 880;
        g.gain.setValueAtTime(0.001, t);
        g.gain.exponentialRampToValueAtTime(0.22, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        o.connect(g); g.connect(ctx.destination);
        o.start(t); o.stop(t + 0.2);
        t += 0.24;
      }
    } catch (_) {}
  }

  /* ============================ HTTP / 会话 ============================ */
  const LOGIN_MARKERS = ['统一身份认证', '用户登录', '请输入密码', '请输入学号', 'type="password"', 'iam.nankai.edu.cn'];
  const FAIL_KWS = ['已满', '冲突', '失败', '错误', '不允许', '不能', '超出', '未开放', '不存在', '禁止', '无法'];

  async function fetchPage(url) {
    const r = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      redirect: 'follow',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/html, */*; q=0.01' },
    });
    return { status: r.status, url: r.url, redirected: r.redirected, text: await r.text() };
  }

  async function checkSession() {
    try {
      const r = await fetchPage(`${BASE}/eams/stdElectCourse.action`);
      if (/login\.action|iam\./i.test(r.url)) return { ok: false, msg: '被重定向到登录页（会话失效）' };
      if (LOGIN_MARKERS.some((m) => r.text.includes(m))) return { ok: false, msg: '返回登录页内容（会话失效）' };
      if (r.status === 200) return { ok: true, msg: '会话有效' };
      return { ok: false, msg: 'HTTP ' + r.status };
    } catch (e) {
      return { ok: false, msg: '网络异常: ' + e };
    }
  }

  function detectProfileId() {
    try {
      const p = new URLSearchParams(location.search).get('electionProfile.id');
      if (p) return p;
    } catch (_) {}
    for (const it of Engine.queue) if (it.profileId) return it.profileId;
    return '';
  }

  async function warmUp(pid) {
    const id = pid || detectProfileId();
    if (!id) {
      Log.add('warn', '未识别选课轮次 profileId，跳过预热（建议在选课页使用，或在队列中添加一个模板任务）');
      return false;
    }
    try {
      await fetchPage(`${BASE}/eams/stdElectCourse!defaultPage.action?electionProfile.id=${id}`);
      Log.add('info', `已预热选课会话（轮次 ${id}）`);
      return true;
    } catch (e) {
      Log.add('warn', '预热请求失败（不影响继续）: ' + e);
      return false;
    }
  }

  /* ============================ 返回分类（移植 grabber.parse_result） ============================ */
  function stripTags(html) {
    return String(html)
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;|&amp;|&lt;|&gt;|&quot;|&#39;|&#\d+;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function around(text, kw, span = 45) {
    const i = text.indexOf(kw);
    if (i < 0) return text.slice(0, 90);
    const s = Math.max(0, i - span);
    return text.slice(s, i + kw.length + span).trim();
  }

  function classify(resp) {
    const { status = 200, redirected = false, finalUrl = '', text = '' } = resp;
    if (redirected || (finalUrl && !/batchOperator/i.test(finalUrl))) {
      if (/login|iam\./i.test(finalUrl)) return { cls: 'EXPIRED', msg: '被重定向到登录页（会话失效）' };
      if (/innerIndex|stdElectCourse/i.test(finalUrl)) {
        return { cls: 'FAIL', msg: '被重定向回选课入口（选课轮次可能已结束或失效），请重新确认轮次' };
      }
      return { cls: 'EXPIRED', msg: '被重定向: ' + String(finalUrl).slice(0, 80) };
    }
    if (status !== 200) return { cls: 'UNKNOWN', msg: `HTTP ${status}: ${stripTags(text).slice(0, 80)}` };
    if (LOGIN_MARKERS.some((m) => text.includes(m))) return { cls: 'EXPIRED', msg: '返回登录页，会话已失效' };

    let data = null;
    try { data = JSON.parse(text); } catch (_) {}
    if (data && typeof data === 'object') {
      const msg = String(data.errorMessage || data.message || data.msg || '');
      if (data.success === true || msg.includes('成功')) return { cls: 'SUCCESS', msg: msg || '成功(JSON)' };
      if (data.success === false || msg) return { cls: 'FAIL', msg: msg || '失败(JSON)' };
      const result = String(data.result || '');
      if (result) return { cls: result.includes('成功') ? 'SUCCESS' : 'FAIL', msg: result };
      return { cls: 'UNKNOWN', msg: '无法识别的JSON: ' + text.slice(0, 80) };
    }

    const plain = stripTags(text);
    if (!plain) return { cls: 'UNKNOWN', msg: '空返回' };
    if (plain.includes('成功') && !plain.includes('失败') && !plain.includes('不成功') && !plain.includes('未成功')) {
      return { cls: 'SUCCESS', msg: around(plain, '成功') };
    }
    if (plain.includes('已选中') || plain.includes('已选上')) return { cls: 'SUCCESS', msg: around(plain, '已选') };
    for (const kw of FAIL_KWS) {
      if (plain.includes(kw)) return { cls: 'FAIL', msg: around(plain, kw) };
    }
    return { cls: 'UNKNOWN', msg: '无法识别的返回: ' + plain.slice(0, 80) };
  }

  /* 移植 grabber._classify：done 选上 / skip 定局失败 / keep 继续发 / session 需重登 */
  function classifyAction(cls, msg) {
    if (cls === 'SUCCESS') return 'done';
    if (cls === 'EXPIRED') return 'session';
    if (['不开放', '未开放'].some((k) => msg.includes(k))) return 'keep';
    if (cls === 'UNKNOWN') return 'keep';
    return 'skip';
  }

  /* ============================ 课程行提取 ============================ */
  /* 等价于 exe 方案里 capture.py 的"抓包"步骤 —— 直接从 DOM 拿课程ID */
  function extractRowInfo(tr) {
    const cells = qsa('td,th', tr).map((td) => td.textContent.trim());
    const rowText = cells.join(' | ') || tr.textContent.trim();

    const countEl = qs('.stdCount', tr);
    const countText = (countEl || { textContent: '' }).textContent.trim();
    let selected = null, total = null;
    const cm = countText.match(/(\d+)\s*\/\s*(\d+)/);
    if (cm) { selected = +cm[1]; total = +cm[2]; }

    const html = tr.outerHTML;
    let lessonId = tr.getAttribute('data-lesson-id') || tr.getAttribute('data-id') || '';
    if (!lessonId) {
      const m =
        html.match(/operator0[=:"]\s*(\d{5,})/i) ||
        html.match(/lesson(?:0|Id)?[=:"]\s*(\d{5,})/i) ||
        html.match(/elect\w*\(,?\s*['"]?(\d{5,})/i) ||
        html.match(/value="(\d{6,})"/);
      if (m) lessonId = m[1];
    }

    let groupId = null;
    const selEl = qs('select[name*="expLessonGroup"]', tr);
    if (selEl && selEl.value && /^\d+$/.test(selEl.value)) groupId = selEl.value;
    if (groupId == null) {
      const m =
        html.match(/expLessonGroup[_\d]*[=:"]+\s*(\d+)/i) ||
        html.match(/expLessonGroup[_\d]*[=:"]+\s*(undefined)/i);
      if (m) groupId = m[1] === 'undefined' ? null : m[1];
    }

    const nameCandidates = cells.filter(
      (c) => /[\u4e00-\u9fa5A-Za-z]{4,}/.test(c) && !c.includes('/') && !/星期|周[0-9一二三四五六七八九十]/.test(c)
    );
    nameCandidates.sort((a, b) => b.length - a.length);
    const name = nameCandidates[0] || cells[1] || rowText.slice(0, 24);

    return { el: tr, lessonId, groupId, name, rowText, countText, selected, total, cells };
  }

  /* ============================ 表格 / 分页 ============================ */
  function gridBody() {
    return (
      qs('#selectableLessonList_data') ||
      qs('tbody[id*="LessonList"]') ||
      (() => { const r = qs('.electGridTr'); return r ? r.parentElement : null; })()
    );
  }
  function gridTable() {
    const b = gridBody();
    return b ? b.closest('table') || b : document.body;
  }
  function pagerNext() { return qs('.pgNextBtn'); }
  function isDisabled(btn) {
    if (!btn) return true;
    if (btn.disabled) return true;
    const c = String(btn.className || '');
    if (/(^|\s)(disabled|ui-state-disabled|pgBtnDisabled)(\s|$)/i.test(c)) return true;
    if (btn.getAttribute('aria-disabled') === 'true') return true;
    const li = btn.closest('li');
    if (li && /(^|\s)disabled(\s|$)/.test(li.className)) return true;
    return false;
  }
  function waitGridChange(timeout = 3500) {
    const target = gridTable();
    return new Promise((resolve) => {
      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        obs.disconnect();
        setTimeout(resolve, 250); // 等渲染稳定
      };
      const obs = new MutationObserver(done);
      obs.observe(target, { childList: true, subtree: true });
      setTimeout(done, timeout);
    });
  }
  function currentRows() { return qsa('.electGridTr').map(extractRowInfo); }

  /* ============================ 多功能搜索（Jquery.txt 升级版） ============================ */
  const Search = {
    running: false,
    abort: false,
    results: [],
    lastKeywords: [],

    parseList(str) {
      return String(str || '').split(/[ ,，;；\n]+/).map((s) => s.trim()).filter(Boolean);
    },

    match(info, opts) {
      const text = info.rowText;
      if (opts.teachers.length && !opts.teachers.some((t) => text.toUpperCase().includes(t.toUpperCase()))) return false;
      if (opts.campuses.length && !opts.campuses.some((c) => text.includes(c))) return false;
      if (opts.onlyAvailable) {
        if (!(info.selected != null && info.total != null && info.selected < info.total)) return false;
      }
      if (opts.keywords.length) {
        const hits = opts.keywords.map((k) => text.toUpperCase().includes(k.toUpperCase()));
        if (opts.logic === 'and') { if (!hits.every(Boolean)) return false; }
        else if (!hits.some(Boolean)) return false;
      }
      return true;
    },

    /* scanPage() 的全页版：收集 -> 翻页 -> 再收集，直到最后一页 */
    async scan(opts, onProgress) {
      this.running = true;
      this.abort = false;
      this.results = [];
      this.lastKeywords = opts.keywords;
      const results = [];
      let step = 0;
      try {
        while (true) {
          if (this.abort) { Log.add('warn', '扫描已手动停止。'); break; }
          const rows = currentRows();
          let hit = 0;
          for (const r of rows) {
            if (this.match(r, opts)) {
              results.push({
                uid: uid(), pageIndex: step + 1,
                lessonId: r.lessonId, groupId: r.groupId,
                name: r.name, rowText: r.rowText, countText: r.countText,
                selected: r.selected, total: r.total,
              });
              hit++;
            }
          }
          onProgress(step + 1, rows.length, hit, results.length);
          const btn = pagerNext();
          if (isDisabled(btn)) { Log.add('info', '已是最后一页，扫描结束。'); break; }
          if (opts.maxPages > 0 && step + 1 >= opts.maxPages) { Log.add('info', `已达到扫描页数上限（${opts.maxPages} 页）。`); break; }
          btn.click();
          await waitGridChange();
          step++;
          await sleep(100);
        }
      } catch (e) {
        Log.add('error', '扫描异常: ' + e);
      } finally {
        this.running = false;
      }
      this.results = results;
      return results;
    },
  };

  /* ---------- 高亮 ---------- */
  let hlMarks = [];
  function clearHighlight() {
    for (const m of hlMarks) {
      const p = m.parentNode;
      if (p) { p.replaceChild(document.createTextNode(m.textContent), m); p.normalize(); }
    }
    hlMarks = [];
  }
  function highlight(keywords) {
    clearHighlight();
    if (!keywords.length) return;
    const root = gridBody();
    if (!root) { Log.add('warn', '当前页面没有课程表格，无法高亮'); return; }
    const rx = new RegExp('(' + keywords.map(escRx).join('|') + ')', 'gi');
    const rxTest = new RegExp('(' + keywords.map(escRx).join('|') + ')', 'i');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        const p = n.parentElement;
        if (!p || /^(script|style|textarea|input)$/i.test(p.tagName)) return NodeFilter.FILTER_REJECT;
        return rxTest.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    for (const node of nodes) {
      const s = node.nodeValue;
      const frag = document.createDocumentFragment();
      let last = 0, m;
      rx.lastIndex = 0;
      while ((m = rx.exec(s))) {
        frag.append(document.createTextNode(s.slice(last, m.index)));
        const mark = el('mark', { class: 'nku-hl' }, m[0]);
        hlMarks.push(mark);
        frag.append(mark);
        last = m.index + m[0].length;
        if (m.index === rx.lastIndex) rx.lastIndex++;
      }
      frag.append(document.createTextNode(s.slice(last)));
      node.parentNode.replaceChild(frag, node);
    }
    Log.add('info', `已在当前页高亮 ${hlMarks.length} 处关键字`);
  }

  /* ---------- 结果定位 ---------- */
  async function jumpToResult(r) {
    const findRow = () =>
      currentRows().find(
        (x) => (r.lessonId && x.lessonId === r.lessonId) || (x.name === r.name && x.countText === r.countText)
      );
    let row = findRow();
    if (!row) {
      // 尝试点击页码按钮跳页
      const pager = pagerNext() && pagerNext().parentElement;
      const btn = pager && qsa('a,button,span,b', pager).find(
        (x) => x.textContent.trim() === String(r.pageIndex) && !isDisabled(x)
      );
      if (btn) {
        btn.click();
        await waitGridChange();
        row = findRow();
      }
    }
    if (row) {
      if (Search.lastKeywords.length) highlight(Search.lastKeywords);
      row.el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      row.el.style.outline = '2px solid #f59e0b';
      setTimeout(() => { row.el.style.outline = ''; }, 2500);
      Log.add('info', `已定位到课程：${r.name}`);
    } else {
      Log.add('warn', `未能在当前视图定位「${r.name}」（扫描时位于第 ${r.pageIndex} 页），请手动翻页后重试`);
    }
  }

  /* ---------- 导出 ---------- */
  function downloadCSV(rows) {
    const head = ['课程名称', '余量', '扫描页码', '课程ID', '分组ID', '行明细'];
    const lines = [head.join(',')].concat(
      rows.map((r) =>
        [r.name, r.countText, r.pageIndex, r.lessonId || '', r.groupId || '', r.rowText]
          .map((v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"')
          .join(',')
      )
    );
    const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = el('a', { href: URL.createObjectURL(blob), download: `选课搜索结果_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.csv` });
    document.body.append(a); a.click(); a.remove();
  }
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); Log.add('info', '已复制到剪贴板'); }
    catch (_) {
      const ta = el('textarea', { style: 'position:fixed;opacity:0' });
      ta.value = text; document.body.append(ta); ta.select();
      try { document.execCommand('copy'); Log.add('info', '已复制到剪贴板'); } catch (e) { Log.add('error', '复制失败: ' + e); }
      ta.remove();
    }
  }

  /* ============================ 发包引擎（grabber.py 浏览器化） ============================ */
  const Engine = {
    running: false,
    stopFlag: false,
    queue: [], // {uid,name,kind:'elect'|'drop',source:'dom'|'template',lessonId,groupId,profileId,url,post,state:'pending'|'done'|'skip',lastMsg,attemptCount}
    mode: 'mixed',
    intervalMs: 520,
    jitterMs: 120,
    stats: { attempt: 0, success: 0, fail: 0 },
    _t0: 0,
  };

  function buildBody(item) {
    if (item.source === 'template' && item.post) return item.post;
    const flag = item.kind === 'drop' ? 'false' : 'true';
    const gid = item.groupId && /^\d+$/.test(item.groupId) ? item.groupId : 'undefined';
    // 与教务系统页面点击"选课"按钮时发出的报文完全一致
    return `optype=true&operator0=${item.lessonId}%3A${flag}%3A0&lesson0=${item.lessonId}&expLessonGroup_${item.lessonId}=${gid}`;
  }
  function buildUrl(item) {
    if (item.source === 'template' && item.url) return item.url;
    const pid = item.profileId || detectProfileId();
    return `${BASE}/eams/stdElectCourse!batchOperator.action?profileId=${pid}`;
  }

  async function sendOnce(item) {
    const url = buildUrl(item);
    const body = buildBody(item);
    Engine._t0 = performance.now();
    const r = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      redirect: 'follow',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'text/html, */*; q=0.01',
      },
      body,
    });
    const text = await r.text();
    return { resp: { status: r.status, redirected: r.redirected, finalUrl: r.url, text }, url, body };
  }

  async function sendAndHandle(item) {
    let result;
    try {
      result = await sendOnce(item);
    } catch (e) {
      Engine.stats.attempt++; Engine.stats.fail++;
      item.lastMsg = '网络异常: ' + e;
      item.attemptCount = (item.attemptCount || 0) + 1;
      Log.add('error', `[${item.name}] 网络异常: ${e}`);
      return 'keep';
    }
    Engine.stats.attempt++;
    const c = classify(result.resp);
    item.lastMsg = c.msg;
    item.attemptCount = (item.attemptCount || 0) + 1;
    item.lastAt = Date.now();
    Log.add(
      c.cls === 'SUCCESS' ? 'success' : c.cls === 'FAIL' ? 'warn' : 'info',
      `[第${Engine.stats.attempt}发] ${item.name}: ${c.msg}`
    );
    if (c.cls === 'SUCCESS') {
      Engine.stats.success++;
      item.state = 'done';
      notify('🎉 选课成功: ' + item.name, c.msg);
      beep(4);
      UI.renderQueue(); persist();
      pushWebhook(`选课成功: ${item.name} —— ${c.msg}`);
    } else {
      Engine.stats.fail++;
    }
    return classifyAction(c.cls, c.msg);
  }

  async function pushWebhook(text) {
    if (!settings.webhook) return;
    try {
      await fetch(settings.webhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
    } catch (e) {
      Log.add('warn', 'webhook 推送失败: ' + e);
    }
  }

  async function pace() {
    const gap = Engine.intervalMs + (Engine.jitterMs > 0 ? Math.random() * Engine.jitterMs : 0);
    const remain = gap - (performance.now() - Engine._t0);
    if (remain > 0) await sleep(remain);
  }

  /* 会话失效：exe 用账号密码自动重登；插件不碰密码 -> 提醒用户登录 + 自动探测恢复 */
  async function waitSessionRecovered() {
    Log.add('warn', '会话失效：请在浏览器中重新登录教务系统，恢复后将自动继续发包…');
    notify('选课助手：会话已失效', '请重新登录教务系统，登录成功后将自动继续发包');
    beep(2);
    while (!Engine.stopFlag) {
      await sleep(15000);
      const c = await checkSession();
      Log.add('info', '会话探测: ' + c.msg);
      if (c.ok) { await warmUp(); Log.add('success', '会话已恢复，继续发包'); return true; }
    }
    return false;
  }

  async function loopMixed() {
    while (!Engine.stopFlag) {
      const list = Engine.queue.filter((i) => i.state === 'pending');
      if (!list.length) { Log.add('success', '所有课程均已处理完毕，任务结束。'); break; }
      const item = list[0];
      const action = await sendAndHandle(item);
      if (action === 'done') { persist(); continue; }
      if (action === 'skip') {
        item.state = 'skip';
        Log.add('warn', `跳过课程 ${item.name}（${item.lastMsg}）——不再发送该课程`);
        persist(); UI.renderQueue(); continue;
      }
      if (action === 'session') { if (await waitSessionRecovered()) continue; else break; }
      await pace();
      const idx = Engine.queue.indexOf(item);
      Engine.queue.splice(idx, 1); Engine.queue.push(item); // 轮转：发完一个换下一个
      UI.renderQueue();
    }
  }

  async function loopPriority() {
    while (!Engine.stopFlag) {
      const item = Engine.queue.find((i) => i.state === 'pending');
      if (!item) { Log.add('success', '所有课程均已处理完毕，任务结束。'); break; }
      const action = await sendAndHandle(item);
      if (action === 'done') { persist(); continue; }
      if (action === 'skip') {
        item.state = 'skip';
        Log.add('warn', `跳过课程 ${item.name}（${item.lastMsg}）——转入下一门`);
        persist(); UI.renderQueue(); continue;
      }
      if (action === 'session') { if (await waitSessionRecovered()) continue; else break; }
      await pace();
    }
  }

  async function loopStakeout() {
    Log.add('info', '蹲点模式：任何失败都不跳过，满员也照发（捡漏退课名额）。');
    while (!Engine.stopFlag) {
      const list = Engine.queue.filter((i) => i.state !== 'done');
      if (!list.length) { Log.add('success', '所有课程均已选上，蹲点完成！'); break; }
      const item = list[0];
      const action = await sendAndHandle(item);
      if (action === 'session') { if (await waitSessionRecovered()) continue; else break; }
      await pace();
      const idx = Engine.queue.indexOf(item);
      Engine.queue.splice(idx, 1); Engine.queue.push(item);
      UI.renderQueue();
    }
  }

  async function startEngine() {
    if (Engine.running) return;
    const pending = Engine.queue.filter((i) => i.state === 'pending');
    if (!pending.length) { Log.add('error', '抢课队列为空（或没有待抢课程），请先添加。'); UI.showTab('grab'); return; }
    const bad = pending.filter((i) => i.source === 'dom' && !/^\d{5,}$/.test(String(i.lessonId || '')));
    if (bad.length === pending.length) {
      Log.add('error', '队列中的课程都无法识别课程ID。请在「抢课」页用【从当前页选择】重新添加，或改用【粘贴模板添加】。');
      UI.showTab('grab'); return;
    }
    if (bad.length) Log.add('warn', `${bad.length} 门课程无有效课程ID，将被跳过（其余照常抢）。`);

    Engine.mode = settings.mode;
    Engine.intervalMs = Math.max(80, +settings.intervalMs || 520);
    Engine.jitterMs = Math.max(0, +settings.jitterMs || 0);
    Engine.stats = { attempt: 0, success: 0, fail: 0 };
    Engine.stopFlag = false;
    Engine.running = true;
    UI.engineState(true);
    try { chrome.runtime.sendMessage({ type: 'badge', text: '抢', color: '#e74c3c' }); } catch (_) {}

    const modeName = { mixed: '混合', priority: '优先', stakeout: '蹲点' }[Engine.mode] || Engine.mode;
    Log.add('info', `开始发包【${modeName}模式】（${Engine.intervalMs}ms/次，抖动 ${Engine.jitterMs}ms）`);
    Log.add('info', '顺序: ' + pending.map((i, idx) => `${idx + 1}.${i.name}`).join(' → '));

    await warmUp();
    try {
      if (Engine.mode === 'priority') await loopPriority();
      else if (Engine.mode === 'stakeout') await loopStakeout();
      else await loopMixed();
    } catch (e) {
      Log.add('error', '引擎异常终止: ' + e);
    }
    Engine.running = false;
    UI.engineState(false);
    try { chrome.runtime.sendMessage({ type: 'badge', text: '' }); } catch (_) {}
    Log.add('info', `结束: 共 ${Engine.stats.attempt} 发, 成功 ${Engine.stats.success} 次, 失败 ${Engine.stats.fail} 次。`);
    beep(1);
  }

  function stopEngine() {
    if (!Engine.running) { Log.add('info', '引擎未在运行。'); return; }
    Engine.stopFlag = true;
    Log.add('warn', '已请求停止，等待当前请求结束后退出…');
  }

  /* ============================ 队列操作 ============================ */
  function addQueueItem(partial) {
    const item = {
      uid: uid(),
      kind: 'elect',
      source: 'dom',
      lessonId: '',
      groupId: null,
      profileId: '',
      url: '',
      post: '',
      name: '未命名课程',
      state: 'pending',
      lastMsg: '',
      attemptCount: 0,
      ...partial,
    };
    if (Engine.queue.some((i) => i.lessonId === item.lessonId && i.source === item.source && item.source === 'dom' && item.lessonId)) {
      Log.add('warn', `课程已在队列中，跳过重复添加：${item.name}`);
      return null;
    }
    Engine.queue.push(item);
    persist(); UI.renderQueue();
    Log.add('info', `已加入抢课队列：${item.name}${item.kind === 'drop' ? '（退课）' : ''}`);
    return item;
  }

  function persist() { store.set({ settings, queue: Engine.queue.map(stripItem) }); }
  function stripItem(i) {
    const { el: _drop, ...rest } = i;
    return rest;
  }

  /* ============================ 面板 UI ============================ */
  const HOST_CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: "Microsoft YaHei", system-ui, -apple-system, sans-serif; }
    .nku-ball {
      position: fixed; right: 18px; bottom: 18px; z-index: 2147483600;
      width: 52px; height: 52px; border-radius: 50%;
      background: linear-gradient(135deg, #2563eb, #7c3aed);
      color: #fff; font-size: 22px; font-weight: 700;
      display: none; align-items: center; justify-content: center;
      cursor: pointer; box-shadow: 0 6px 20px rgba(37,99,235,.45);
      user-select: none; border: 2px solid rgba(255,255,255,.7);
    }
    .nku-ball:hover { transform: scale(1.06); }
    .nku-panel {
      position: fixed; right: 16px; top: 72px; z-index: 2147483601;
      width: 420px; max-height: calc(100vh - 90px);
      background: #fff; border-radius: 14px;
      box-shadow: 0 12px 48px rgba(15,23,42,.28), 0 0 0 1px rgba(15,23,42,.06);
      display: flex; flex-direction: column; overflow: hidden;
      color: #1f2937; font-size: 13px;
    }
    .nku-head {
      background: linear-gradient(135deg, #1d4ed8, #6d28d9); color: #fff;
      padding: 10px 12px; display: flex; align-items: center; gap: 8px; cursor: move;
      user-select: none;
    }
    .nku-head .nku-title { font-weight: 700; font-size: 14px; flex: 1; letter-spacing: .5px; }
    .nku-dot { width: 9px; height: 9px; border-radius: 50%; background: #94a3b8; box-shadow: 0 0 0 3px rgba(255,255,255,.15); }
    .nku-dot.on { background: #22c55e; }
    .nku-dot.err { background: #ef4444; }
    .nku-dot.busy { background: #f59e0b; animation: nkupulse 1s infinite; }
    @keyframes nkupulse { 50% { opacity: .4; } }
    .nku-headbtn {
      background: rgba(255,255,255,.18); border: 0; color: #fff; width: 24px; height: 24px;
      border-radius: 6px; cursor: pointer; font-size: 13px; line-height: 1;
    }
    .nku-headbtn:hover { background: rgba(255,255,255,.32); }
    .nku-tabs { display: flex; background: #f1f5f9; border-bottom: 1px solid #e2e8f0; }
    .nku-tab {
      flex: 1; text-align: center; padding: 8px 0; cursor: pointer; font-size: 13px;
      color: #475569; border: 0; background: transparent; border-bottom: 2px solid transparent;
    }
    .nku-tab:hover { color: #1d4ed8; }
    .nku-tab.active { color: #1d4ed8; font-weight: 700; border-bottom-color: #1d4ed8; background: #fff; }
    .nku-page { display: none; padding: 10px 12px; overflow-y: auto; flex: 1; }
    .nku-page.active { display: block; }
    .nku-row { display: flex; gap: 6px; align-items: center; margin-bottom: 8px; flex-wrap: wrap; }
    .nku-row label.nku-lb { font-size: 12px; color: #64748b; min-width: 56px; }
    .nku-input, .nku-select, .nku-textarea {
      border: 1px solid #cbd5e1; border-radius: 7px; padding: 5px 8px; font-size: 12.5px;
      outline: none; background: #fff; color: #1f2937; flex: 1; min-width: 0;
    }
    .nku-input:focus, .nku-textarea:focus, .nku-select:focus { border-color: #2563eb; box-shadow: 0 0 0 2px rgba(37,99,235,.15); }
    .nku-textarea { width: 100%; resize: vertical; font-family: Consolas, monospace; }
    .nku-btn {
      border: 0; border-radius: 7px; padding: 6px 12px; font-size: 12.5px; cursor: pointer;
      background: #e2e8f0; color: #1e293b; white-space: nowrap;
    }
    .nku-btn:hover { filter: brightness(.96); }
    .nku-btn.primary { background: #2563eb; color: #fff; }
    .nku-btn.primary:hover { background: #1d4ed8; }
    .nku-btn.danger { background: #ef4444; color: #fff; }
    .nku-btn.danger:hover { background: #dc2626; }
    .nku-btn.ok { background: #16a34a; color: #fff; }
    .nku-btn.small { padding: 2px 7px; font-size: 11.5px; border-radius: 5px; }
    .nku-btn:disabled { opacity: .5; cursor: not-allowed; }
    .nku-tip { font-size: 11.5px; color: #94a3b8; line-height: 1.5; margin: 4px 0 8px; }
    .nku-progress { font-size: 12px; color: #2563eb; background: #eff6ff; border-radius: 6px; padding: 5px 8px; margin-bottom: 8px; display: none; }
    .nku-results { border: 1px solid #e2e8f0; border-radius: 8px; max-height: 260px; overflow-y: auto; }
    .nku-result { padding: 7px 9px; border-bottom: 1px solid #f1f5f9; display: flex; gap: 8px; align-items: center; }
    .nku-result:last-child { border-bottom: 0; }
    .nku-result:hover { background: #f8fafc; }
    .nku-result .nku-rname { flex: 1; min-width: 0; }
    .nku-result .nku-rname b { display: block; font-size: 12.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .nku-result .nku-rmeta { font-size: 11px; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
    .nku-badge { font-size: 11px; border-radius: 5px; padding: 1.5px 6px; white-space: nowrap; }
    .nku-badge.full { background: #fee2e2; color: #b91c1c; }
    .nku-badge.free { background: #dcfce7; color: #15803d; }
    .nku-badge.unk { background: #f1f5f9; color: #64748b; }
    .nku-badge.drop { background: #fef3c7; color: #b45309; }
    .nku-badge.tpl { background: #ede9fe; color: #6d28d9; }
    .nku-badge.st-done { background: #dcfce7; color: #15803d; }
    .nku-badge.st-skip { background: #fee2e2; color: #b91c1c; }
    .nku-badge.st-pending { background: #e0e7ff; color: #4338ca; }
    .nku-queue-item { border: 1px solid #e2e8f0; border-radius: 8px; padding: 7px 9px; margin-bottom: 6px; }
    .nku-queue-item.done { opacity: .62; background: #f8fafc; }
    .nku-qtop { display: flex; align-items: center; gap: 6px; }
    .nku-qtop .nku-qname { flex: 1; font-weight: 600; font-size: 12.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .nku-qmsg { font-size: 11px; color: #94a3b8; margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .nku-modal-mask {
      position: fixed; inset: 0; z-index: 2147483602; background: rgba(15,23,42,.45);
      display: flex; align-items: center; justify-content: center;
    }
    .nku-modal {
      width: 520px; max-width: 92vw; max-height: 84vh; background: #fff; border-radius: 12px;
      display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,.35);
      font-size: 13px; color: #1f2937;
    }
    .nku-modal-head { padding: 10px 14px; font-weight: 700; border-bottom: 1px solid #e2e8f0; display: flex; }
    .nku-modal-head span { flex: 1; }
    .nku-modal-body { padding: 12px 14px; overflow-y: auto; }
    .nku-pick-item { display: flex; gap: 8px; align-items: center; padding: 6px 4px; border-bottom: 1px solid #f1f5f9; }
    .nku-pick-item:hover { background: #f8fafc; }
    .nku-pick-name { flex: 1; min-width: 0; font-size: 12.5px; }
    .nku-pick-meta { font-size: 11px; color: #94a3b8; }
    .nku-logbox {
      font-family: Consolas, "Courier New", monospace; font-size: 11.5px; line-height: 1.6;
      background: #0f172a; color: #cbd5e1; border-radius: 8px; padding: 8px 10px;
      height: 300px; overflow-y: auto; white-space: pre-wrap; word-break: break-all;
    }
    .nku-log-success { color: #4ade80; }
    .nku-log-warn { color: #fbbf24; }
    .nku-log-error { color: #f87171; }
    .nku-log-info { color: #cbd5e1; }
    .nku-stats { display: flex; gap: 10px; font-size: 12px; color: #475569; background: #f8fafc; border-radius: 7px; padding: 6px 10px; margin-bottom: 8px; }
    .nku-stats b { color: #1d4ed8; }
    .nku-hl { background: #fde047; color: #713f12; border-radius: 2px; padding: 0 1px; }
    .nku-divider { border: 0; border-top: 1px dashed #e2e8f0; margin: 10px 0; }
    .nku-session-banner {
      display: none; background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca;
      border-radius: 8px; padding: 7px 10px; font-size: 12px; margin-bottom: 8px;
    }
    .nku-session-banner.show { display: block; }
  `;

  const UI = {
    host: null, panel: null, ball: null,
    logBox: null, queueBox: null, resultBox: null,
    progressBar: null, statsBox: null, sessionBanner: null,
    visible: false,

    showTab(name) {
      for (const t of this.shadow.querySelectorAll('.nku-tab')) {
        t.classList.toggle('active', t.dataset.tab === name);
      }
      for (const p of this.shadow.querySelectorAll('.nku-page')) {
        p.classList.toggle('active', p.dataset.page === name);
      }
    },

    open() { this.visible = true; this.panel.style.display = 'flex'; this.ball.style.display = 'none'; },
    close() { this.visible = false; this.panel.style.display = 'none'; this.ball.style.display = 'flex'; },
    toggle() { this.visible ? this.close() : this.open(); },

    engineState(running) {
      const dot = this.shadow && this.shadow.querySelector('.nku-dot');
      if (dot) { dot.className = 'nku-dot ' + (running ? 'busy' : 'on'); dot.title = running ? '发包运行中' : '空闲'; }
      if (this.btnStart) this.btnStart.disabled = running;
      if (this.btnStop) this.btnStop.disabled = !running;
    },

    flashSession() {
      if (this.sessionBanner) this.sessionBanner.classList.add('show');
      const dot = this.shadow && this.shadow.querySelector('.nku-dot');
      if (dot) dot.className = 'nku-dot err';
    },

    setProgress(text) {
      if (!this.progressBar) return;
      if (!text) { this.progressBar.style.display = 'none'; return; }
      this.progressBar.style.display = 'block';
      this.progressBar.textContent = text;
    },

    renderQueue() {
      if (!this.queueBox) return;
      this.queueBox.innerHTML = '';
      if (!Engine.queue.length) {
        this.queueBox.append(el('div', { class: 'nku-tip' }, '队列为空。可通过搜索结果页的【加入抢课】、【从当前页选择】或【粘贴模板添加】来添加课程。'));
        return;
      }
      Engine.queue.forEach((item, idx) => {
        const stBadge =
          item.state === 'done' ? el('span', { class: 'nku-badge st-done' }, '已选上') :
          item.state === 'skip' ? el('span', { class: 'nku-badge st-skip' }, '已跳过') :
            el('span', { class: 'nku-badge st-pending' }, '待发');
        const kindBadge = item.kind === 'drop'
          ? el('span', { class: 'nku-badge drop' }, '退课')
          : null;
        const srcBadge = item.source === 'template'
          ? el('span', { class: 'nku-badge tpl' }, '模板')
          : null;
        const meta = item.source === 'template'
          ? (item.post || '').slice(0, 60)
          : `ID:${item.lessonId || '?'}${item.groupId ? ' 组:' + item.groupId : ''}`;
        const row = el(
          'div',
          { class: 'nku-queue-item' + (item.state === 'done' ? ' done' : ''), title: item.lastMsg || meta },
          el('div', { class: 'nku-qtop' },
            el('span', { style: 'color:#94a3b8;font-size:11px;width:16px' }, String(idx + 1)),
            el('span', { class: 'nku-qname' }, item.name),
            stBadge, kindBadge, srcBadge,
            el('button', { class: 'nku-btn small', title: '上移', onclick: () => moveQueue(idx, -1) }, '↑'),
            el('button', { class: 'nku-btn small', title: '下移', onclick: () => moveQueue(idx, 1) }, '↓'),
            el('button', { class: 'nku-btn small primary', title: '单发一次（校准用）', onclick: () => sendOneManual(item) }, '单发'),
            el('button', { class: 'nku-btn small danger', title: '移除', onclick: () => removeQueue(item) }, '✕')
          ),
          el('div', { class: 'nku-qmsg' },
            `${meta}${item.attemptCount ? ` · 已发${item.attemptCount}次` : ''}${item.lastMsg ? ' · ' + item.lastMsg : ''}`)
        );
        this.queueBox.append(row);
      });
    },

    renderResults() {
      if (!this.resultBox) return;
      this.resultBox.innerHTML = '';
      if (!Search.results.length) {
        this.resultBox.append(el('div', { class: 'nku-tip', style: 'padding:8px' }, '暂无搜索结果。设置好条件后点击【全页扫描】或【扫当前页】。'));
        return;
      }
      for (const r of Search.results) {
        const free = r.selected != null && r.total != null && r.selected < r.total;
        this.resultBox.append(
          el('div', { class: 'nku-result' },
            el('span', { class: 'nku-badge ' + (free ? 'free' : r.selected != null ? 'full' : 'unk') }, r.countText || '余量未知'),
            el('span', { class: 'nku-rname' },
              el('b', { title: r.name }, r.name),
              el('span', { class: 'nku-rmeta', title: r.rowText }, `第${r.pageIndex}页 · ${r.rowText.slice(0, 46)}`)
            ),
            el('button', { class: 'nku-btn small primary', onclick: () => {
              addQueueItem({ name: r.name, lessonId: r.lessonId, groupId: r.groupId, source: 'dom' });
              this.showTab('grab');
            } }, '加入抢课'),
            el('button', { class: 'nku-btn small', onclick: () => jumpToResult(r) }, '定位')
          )
        );
      }
    },

    renderStats() {
      if (!this.statsBox) return;
      this.statsBox.innerHTML = '';
      this.statsBox.append(
        el('span', {}, '已发 ', el('b', {}, String(Engine.stats.attempt))),
        el('span', {}, '成功 ', el('b', {}, String(Engine.stats.success))),
        el('span', {}, '失败 ', el('b', {}, String(Engine.stats.fail))),
        el('span', {}, '待发 ', el('b', {}, String(Engine.queue.filter((i) => i.state === 'pending').length)))
      );
    },
  };

  function moveQueue(idx, dir) {
    const j = idx + dir;
    if (j < 0 || j >= Engine.queue.length) return;
    [Engine.queue[idx], Engine.queue[j]] = [Engine.queue[j], Engine.queue[idx]];
    persist(); UI.renderQueue();
  }
  function removeQueue(item) {
    Engine.queue = Engine.queue.filter((i) => i !== item);
    persist(); UI.renderQueue();
    Log.add('info', '已移除：' + item.name);
  }
  async function sendOneManual(item) {
    if (Engine.running) { Log.add('warn', '引擎运行中，请先停止再单发测试。'); return; }
    if (item.source === 'dom' && !/^\d{5,}$/.test(String(item.lessonId || ''))) {
      Log.add('error', `「${item.name}」没有有效的课程ID，无法单发。`);
      return;
    }
    Log.add('info', `单发测试：${item.name} → ${buildUrl(item)}`);
    Log.add('info', `报文: ${buildBody(item)}`);
    const action = await sendAndHandle(item);
    if (action === 'skip') item.state = item.state === 'done' ? 'done' : 'skip';
    UI.renderQueue(); UI.renderStats();
  }

  /* ---------- 抓取当前页课程（选择器弹窗） ---------- */
  function openPicker() {
    const rows = currentRows();
    if (!rows.length) {
      Log.add('warn', '当前页面没有找到课程表格（.electGridTr）。请先进入选课页面的课程列表。');
      return;
    }
    let checked = new Set();
    const listWrap = el('div', {});
    const renderList = (filter) => {
      listWrap.innerHTML = '';
      for (const r of rows) {
        if (filter && !r.rowText.toUpperCase().includes(filter.toUpperCase())) continue;
        const cb = el('input', { type: 'checkbox' });
        cb.checked = checked.has(r);
        cb.addEventListener('change', () => { cb.checked ? checked.add(r) : checked.delete(r); });
        listWrap.append(
          el('div', { class: 'nku-pick-item' }, cb,
            el('div', { class: 'nku-pick-name' },
              el('div', {}, el('b', {}, r.name)),
              el('span', { class: 'nku-pick-meta' }, `ID:${r.lessonId || '未识别'} 余量:${r.countText || '?'} · ${r.rowText.slice(0, 40)}`)
            ),
            !r.lessonId ? el('span', { class: 'nku-badge full', title: '未能从该行提取课程ID，可改用模板方式' }, 'ID?') : null
          )
        );
      }
      if (!listWrap.children.length) listWrap.append(el('div', { class: 'nku-tip' }, '没有匹配的课程行。'));
    };
    renderList('');

    const searchInput = el('input', { class: 'nku-input', placeholder: '在当前页课程中过滤…' });
    searchInput.addEventListener('input', () => renderList(searchInput.value.trim()));

    const mask = el('div', { class: 'nku-modal-mask' },
      el('div', { class: 'nku-modal' },
        el('div', { class: 'nku-modal-head' }, el('span', {}, `选择要抢的课程（当前页 ${rows.length} 门）`),
          el('button', { class: 'nku-headbtn', style: 'background:#e2e8f0;color:#334155', onclick: () => mask.remove() }, '✕')),
        el('div', { class: 'nku-modal-body' },
          el('div', { class: 'nku-row' }, searchInput,
            el('button', { class: 'nku-btn small', onclick: () => { rows.forEach((r) => checked.add(r)); renderList(searchInput.value.trim()); } }, '全选'),
            el('button', { class: 'nku-btn small', onclick: () => { checked.clear(); renderList(searchInput.value.trim()); } }, '全不选')),
          listWrap),
        el('div', { class: 'nku-modal-body', style: 'border-top:1px solid #e2e8f0;padding-top:8px;display:flex;gap:8px;justify-content:flex-end' },
          el('button', { class: 'nku-btn', onclick: () => mask.remove() }, '取消'),
          el('button', { class: 'nku-btn primary', onclick: () => {
            let added = 0;
            for (const r of checked) {
              if (!r.lessonId) { Log.add('warn', `「${r.name}」无法识别课程ID，已跳过（可稍后用模板方式添加）`); continue; }
              if (addQueueItem({ name: r.name, lessonId: r.lessonId, groupId: r.groupId, source: 'dom' })) added++;
            }
            mask.remove();
            Log.add('info', `已从当前页添加 ${added} 门课程到队列。`);
            UI.showTab('grab');
          } }, `加入队列`))
      )
    );
    UI.shadow.appendChild(mask);
  }

  /* ---------- 模板添加（等价 exe 的 captured/<seq>.json 重放） ---------- */
  function openTemplateModal() {
    const postTa = el('textarea', { class: 'nku-textarea', rows: 4, placeholder: '粘贴报文，例如：\noptype=true&operator0=650670%3Atrue%3A0&lesson0=650670&expLessonGroup_650670=undefined' });
    const urlInput = el('input', { class: 'nku-input', placeholder: '请求地址（可留空，默认按当前轮次拼 batchOperator 地址）' });
    const nameInput = el('input', { class: 'nku-input', placeholder: '课程名称（选填，便于识别）' });
    const kindSel = el('select', { class: 'nku-select', style: 'flex:0 0 110px' },
      el('option', { value: 'elect' }, '选课'), el('option', { value: 'drop' }, '退课'));

    const mask = el('div', { class: 'nku-modal-mask' },
      el('div', { class: 'nku-modal' },
        el('div', { class: 'nku-modal-head' }, el('span', {}, '粘贴模板添加（DevTools 复制的选课报文）'),
          el('button', { class: 'nku-headbtn', style: 'background:#e2e8f0;color:#334155', onclick: () => mask.remove() }, '✕')),
        el('div', { class: 'nku-modal-body' },
          el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '名称'), nameInput),
          el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '类型'), kindSel),
          el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '地址'), urlInput),
          el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '报文'), postTa),
          el('div', { class: 'nku-tip' },
            '获取方式：在选课页面点击任一课程的"选课"按钮，打开 DevTools → 网络(Network) → 找到 batchOperator 请求 → 右键"复制" → "复制请求体"。重放时会自动使用浏览器当前登录会话。')),
        el('div', { class: 'nku-modal-body', style: 'border-top:1px solid #e2e8f0;padding-top:8px;display:flex;gap:8px;justify-content:flex-end' },
          el('button', { class: 'nku-btn', onclick: () => mask.remove() }, '取消'),
          el('button', { class: 'nku-btn primary', onclick: () => {
            const post = postTa.value.trim();
            if (!post || !/operator0=\d+/.test(post)) {
              Log.add('error', '报文无效：必须包含 operator0=<课程ID>。请重新复制请求体。');
              return;
            }
            const idm = post.match(/operator0=(\d+)/);
            let url = urlInput.value.trim();
            let profileId = '';
            const pm = url.match(/profileId=(\d+)/);
            if (pm) profileId = pm[1];
            if (!url) url = `${BASE}/eams/stdElectCourse!batchOperator.action?profileId=${detectProfileId() || '0'}`;
            addQueueItem({
              name: nameInput.value.trim() || (idm ? '模板课程 ' + idm[1] : '模板课程'),
              kind: kindSel.value, source: 'template',
              lessonId: idm ? idm[1] : '', url, post, profileId,
            });
            mask.remove();
            UI.showTab('grab');
          } }, '添加'))
      )
    );
    UI.shadow.appendChild(mask);
  }

  /* ---------- 构建面板 ---------- */
  async function buildPanel() {
    const host = document.createElement('div');
    host.id = 'nku-ext-host';
    const shadow = host.attachShadow({ mode: 'open' });
    UI.host = host; UI.shadow = shadow;

    /* --- 搜索页 --- */
    const kwInput = el('input', { class: 'nku-input', placeholder: '关键字，多关键字用空格/逗号分隔（留空=不过滤）' });
    const logicSel = el('select', { class: 'nku-select', style: 'flex:0 0 76px' },
      el('option', { value: 'or' }, '任一命中'), el('option', { value: 'and' }, '全部命中'));
    logicSel.value = settings.searchLogic;
    const teacherInput = el('input', { class: 'nku-input', placeholder: '教师（选填，多人用逗号分隔）' });
    const campusInput = el('input', { class: 'nku-input', placeholder: '校区（选填，如：津南 / 八里台 / 泰达）' });
    const onlyAvail = el('input', { type: 'checkbox' });
    onlyAvail.checked = settings.searchOnlyAvailable;
    const maxPagesInput = el('input', { class: 'nku-input', type: 'number', min: 0, style: 'flex:0 0 70px', title: '0 表示全部页' });
    maxPagesInput.value = String(settings.searchMaxPages);

    const progressBar = el('div', { class: 'nku-progress' });
    const resultBox = el('div', { class: 'nku-results' });
    UI.progressBar = progressBar; UI.resultBox = resultBox;

    function collectOpts() {
      return {
        keywords: Search.parseList(kwInput.value),
        logic: logicSel.value,
        teachers: Search.parseList(teacherInput.value),
        campuses: Search.parseList(campusInput.value),
        onlyAvailable: onlyAvail.checked,
        maxPages: Math.max(0, parseInt(maxPagesInput.value, 10) || 0),
      };
    }
    function saveSearchSettings() {
      settings.searchLogic = logicSel.value;
      settings.searchOnlyAvailable = onlyAvail.checked;
      settings.searchMaxPages = Math.max(0, parseInt(maxPagesInput.value, 10) || 0);
      persist();
    }

    const searchPage = el('div', { class: 'nku-page', 'data-page': 'search' },
      el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '关键字'), kwInput),
      el('div', { class: 'nku-row' },
        el('label', { class: 'nku-lb' }, '匹配'), logicSel,
        el('label', { class: 'nku-lb', style: 'min-width:86px' }, onlyAvail, ' 只看有余量'),
        el('label', { class: 'nku-lb' }, '页数'), maxPagesInput),
      el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '教师'), teacherInput),
      el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, '校区'), campusInput),
      el('div', { class: 'nku-row' },
        el('button', { class: 'nku-btn primary', onclick: async () => {
          if (Search.running) return;
          if (!gridBody()) { Log.add('error', '当前页面没有课程表格。请先进入选课页面的【可选课程】列表。'); return; }
          const opts = collectOpts(); saveSearchSettings();
          UI.showTab('search');
          Log.add('info', `开始全页扫描：关键字[${opts.keywords.join('/')||'无'}] ${opts.onlyAvailable ? '仅看有余量' : ''}`);
          const res = await Search.scan(opts, (page, rows, hit, total) => {
            UI.setProgress(`正在扫描… 第 ${page} 页 · 本页 ${rows.length} 门 · 命中 ${hit} · 累计 ${total}`);
          });
          UI.setProgress(null);
          UI.renderResults();
          if (opts.keywords.length) highlight(opts.keywords);
          Log.add('success', `扫描完成：共命中 ${res.length} 门课程。`);
          if (res.length) beep(1);
        } }, '🔍 全页扫描'),
        el('button', { class: 'nku-btn', onclick: async () => {
          if (Search.running) return;
          if (!gridBody()) { Log.add('error', '当前页面没有课程表格。'); return; }
          const opts = collectOpts(); saveSearchSettings();
          opts.maxPages = 1;
          Search.lastKeywords = opts.keywords;
          const found = [];
          for (const r of currentRows()) {
            if (Search.match(r, opts)) {
              const item = { uid: uid(), pageIndex: null, lessonId: r.lessonId, groupId: r.groupId, name: r.name, rowText: r.rowText, countText: r.countText, selected: r.selected, total: r.total };
              // 与已有结果去重（同一门课不重复入列）
              if (!Search.results.some((x) => x.name === item.name && x.countText === item.countText)) found.push(item);
            }
          }
          Search.results = found.concat(Search.results);
          UI.renderResults();
          if (opts.keywords.length) highlight(opts.keywords);
          Log.add('info', `当前页命中 ${found.length} 门课程。`);
        } }, '扫当前页'),
        el('button', { class: 'nku-btn danger', onclick: () => { Search.abort = true; } }, '停止'),
        el('button', { class: 'nku-btn', onclick: () => highlight(Search.parseList(kwInput.value)) }, '高亮'),
        el('button', { class: 'nku-btn', onclick: () => { clearHighlight(); } }, '取消高亮')),
      el('div', { class: 'nku-row' },
        el('button', { class: 'nku-btn', onclick: () => downloadCSV(Search.results) }, '导出CSV'),
        el('button', { class: 'nku-btn', onclick: () => copyText(Search.results.map((r) => `${r.name} ${r.countText || ''} ${r.rowText}`).join('\n')) }, '复制结果'),
        el('button', { class: 'nku-btn', onclick: () => { Search.results = []; UI.renderResults(); } }, '清空结果')),
      progressBar, resultBox,
      el('div', { class: 'nku-tip' }, '说明：扫描会自动翻页（点击下一页并等待表格刷新），与控制台脚本 scanPage() 逻辑一致但无需手动粘贴代码；命中结果可一键【加入抢课】。')
    );

    /* --- 抢课页 --- */
    const queueBox = el('div', {});
    UI.queueBox = queueBox;
    const statsBox = el('div', { class: 'nku-stats' });
    UI.statsBox = statsBox;
    const sessionBanner = el('div', { class: 'nku-session-banner' },
      '⚠ 会话已失效：请在浏览器中重新登录教务系统。本助手不保存账号密码，检测到登录后会自动继续发包。');
    UI.sessionBanner = sessionBanner;

    const modeSel = el('select', { class: 'nku-select', style: 'flex:0 0 108px' },
      el('option', { value: 'mixed' }, '混合轮询'),
      el('option', { value: 'priority' }, '优先模式'),
      el('option', { value: 'stakeout' }, '蹲点捡漏'));
    modeSel.value = settings.mode;
    modeSel.addEventListener('change', () => { settings.mode = modeSel.value; persist(); });

    const intervalInput = el('input', { class: 'nku-input', type: 'number', min: 80, step: 20, style: 'flex:0 0 78px', title: '两次发包的间隔毫秒' });
    intervalInput.value = String(settings.intervalMs);
    intervalInput.addEventListener('change', () => { settings.intervalMs = Math.max(80, +intervalInput.value || 520); intervalInput.value = String(settings.intervalMs); persist(); });

    const jitterInput = el('input', { class: 'nku-input', type: 'number', min: 0, step: 20, style: 'flex:0 0 78px', title: '随机抖动毫秒，0 为关闭' });
    jitterInput.value = String(settings.jitterMs);
    jitterInput.addEventListener('change', () => { settings.jitterMs = Math.max(0, +jitterInput.value || 0); jitterInput.value = String(settings.jitterMs); persist(); });

    const btnStart = el('button', { class: 'nku-btn ok', onclick: () => startEngine() }, '▶ 开始发包');
    const btnStop = el('button', { class: 'nku-btn danger', disabled: true, onclick: () => stopEngine() }, '⏹ 停止');
    UI.btnStart = btnStart; UI.btnStop = btnStop;

    const profileSpan = el('span', { style: 'color:#64748b;font-size:12px' }, detectProfileId() || '未识别');

    const grabPage = el('div', { class: 'nku-page', 'data-page': 'grab' },
      sessionBanner,
      el('div', { class: 'nku-row' },
        el('button', { class: 'nku-btn primary', onclick: openPicker }, '➕ 从当前页选择'),
        el('button', { class: 'nku-btn', onclick: openTemplateModal }, '📋 粘贴模板添加')),
      el('div', { class: 'nku-tip' }, '未打开课程表格时，用【粘贴模板添加】最稳妥：把页面上手动选课一次的请求体贴进来即可反复重放。'),
      el('hr', { class: 'nku-divider' }),
      el('div', { class: 'nku-row' },
        el('label', { class: 'nku-lb' }, '模式'), modeSel,
        el('label', { class: 'nku-lb' }, '间隔ms'), intervalInput,
        el('label', { class: 'nku-lb' }, '抖动ms'), jitterInput),
      el('div', { class: 'nku-row' }, btnStart, btnStop,
        el('button', { class: 'nku-btn', onclick: async () => {
          const c = await checkSession();
          Log.add(c.ok ? 'success' : 'error', '会话检测: ' + c.msg);
          if (!c.ok) UI.flashSession(); else if (UI.sessionBanner) UI.sessionBanner.classList.remove('show');
        } }, '检测会话'),
        el('button', { class: 'nku-btn', onclick: () => window.open(BASE + '/eams/home.action', '_blank') }, '打开登录页')),
      statsBox,
      el('div', { class: 'nku-row' },
        el('span', { class: 'nku-lb', style: 'min-width:auto' }, '轮次: ', profileSpan)),
      el('hr', { class: 'nku-divider' }),
      el('div', { class: 'nku-row', style: 'justify-content:space-between' },
        el('b', { style: 'font-size:12.5px;color:#475569' }, '抢课队列'),
        el('span', {},
          el('button', { class: 'nku-btn small', title: '把已完成/已跳过的课程恢复为待发', onclick: () => {
            Engine.queue.forEach((i) => { if (i.state !== 'pending') { i.state = 'pending'; i.lastMsg = ''; } });
            persist(); UI.renderQueue(); Log.add('info', '已重置队列状态。');
          } }, '重置状态'),
          el('button', { class: 'nku-btn small danger', onclick: () => {
            if (!Engine.queue.length) return;
            Engine.queue = []; persist(); UI.renderQueue(); Log.add('warn', '已清空队列。');
          } }, '清空'))),
      queueBox,
      el('div', { class: 'nku-tip' },
        '模式说明 —— 混合轮询：多门课轮流发包，选上/定局失败自动移出；优先模式：集中发第一门，结束再转下一门；蹲点捡漏：满员也照发，等人退课，任何失败都不跳过。失败判定"已满/冲突/不在培养方案"会跳过该课以保住后面的课；"未开放/网络异常/无法识别"会继续发。')
    );

    /* --- 日志页 --- */
    const logBox = el('div', { class: 'nku-logbox' });
    UI.logBox = logBox;
    const soundCk = el('input', { type: 'checkbox' });
    soundCk.checked = !!settings.sound;
    soundCk.addEventListener('change', () => { settings.sound = soundCk.checked; persist(); });
    const notifyCk = el('input', { type: 'checkbox' });
    notifyCk.checked = !!settings.notifyOnSuccess;
    notifyCk.addEventListener('change', () => { settings.notifyOnSuccess = notifyCk.checked; persist(); });
    const webhookInput = el('input', { class: 'nku-input', placeholder: 'webhook 地址（选填，成功时 POST JSON）' });
    webhookInput.value = settings.webhook || '';
    webhookInput.addEventListener('change', () => { settings.webhook = webhookInput.value.trim(); persist(); });

    const logPage = el('div', { class: 'nku-page', 'data-page': 'log' },
      logBox,
      el('div', { class: 'nku-row', style: 'margin-top:8px' },
        el('button', { class: 'nku-btn', onclick: () => copyText(Log.text()) }, '复制日志'),
        el('button', { class: 'nku-btn danger', onclick: () => Log.clear() }, '清空日志')),
      el('hr', { class: 'nku-divider' }),
      el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb', style: 'min-width:110px' }, soundCk, ' 成功提示音'),
        el('label', { class: 'nku-lb', style: 'min-width:auto' }, notifyCk, ' 桌面通知')),
      el('div', { class: 'nku-row' }, el('label', { class: 'nku-lb' }, 'Webhook'), webhookInput)
    );

    /* --- 头部 & 标签 --- */
    const dot = el('span', { class: 'nku-dot on', title: '空闲' });
    const head = el('div', { class: 'nku-head' }, dot,
      el('span', { class: 'nku-title' }, '南开选课助手'),
      el('button', { class: 'nku-headbtn', title: '收起', onclick: () => UI.close() }, '—'));
    // 拖动
    head.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      const rect = UI.panel.getBoundingClientRect();
      const dx = e.clientX - rect.left, dy = e.clientY - rect.top;
      const move = (ev) => {
        UI.panel.style.left = Math.max(0, ev.clientX - dx) + 'px';
        UI.panel.style.top = Math.max(0, ev.clientY - dy) + 'px';
        UI.panel.style.right = 'auto';
      };
      const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      e.preventDefault();
    });

    const mkTab = (name, label, page) =>
      el('button', { class: 'nku-tab' + (page === 'search' ? ' active' : ''), 'data-tab': page, onclick: () => UI.showTab(page) }, label);

    const panel = el('div', { class: 'nku-panel', style: 'display:none' },
      head,
      el('div', { class: 'nku-tabs' }, mkTab('search', '🔍 搜索', 'search'), mkTab('grab', '🚀 抢课', 'grab'), mkTab('log', '📜 日志/设置', 'log')),
      searchPage, grabPage, logPage);

    const ball = el('div', { class: 'nku-ball', title: '打开选课助手 (Alt+Shift+O)', onclick: () => UI.open() }, '选');

    shadow.append(el('style', {}, HOST_CSS), panel, ball);
    document.documentElement.append(host);
    UI.panel = panel; UI.ball = ball;

    Log.render();
    UI.renderQueue();
    UI.renderResults();
    UI.renderStats();
    UI.showTab(IS_ELECT_PAGE ? 'search' : 'grab');

    if (IS_ELECT_PAGE) UI.open(); else UI.close();

    setInterval(() => { if (!Engine.running) UI.renderStats(); }, 3000);
  }

  /* ============================ 消息（popup / 快捷键） ============================ */
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== 'object') return;
    switch (msg.type) {
      case 'toggle-panel':
        UI.toggle();
        sendResponse({ ok: true });
        break;
      case 'open-panel':
        UI.open(); UI.showTab(msg.tab || 'search');
        sendResponse({ ok: true });
        break;
      case 'popup-state':
        sendResponse({
          ok: true,
          injected: true,
          engineRunning: Engine.running,
          queueLen: Engine.queue.filter((i) => i.state === 'pending').length,
          scanning: Search.running,
          stats: { ...Engine.stats },
        });
        break;
      case 'stop-engine':
        stopEngine();
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false });
    }
    return true;
  });

  /* ============================ 启动 ============================ */
  (async () => {
    const saved = await store.get(['settings', 'queue'], { settings: DEFAULT_SETTINGS, queue: [] });
    if (saved.settings) settings = { ...DEFAULT_SETTINGS, ...saved.settings };
    if (Array.isArray(saved.queue)) {
      Engine.queue = saved.queue.map((i) => ({ state: 'pending', attemptCount: 0, lastMsg: '', ...i, el: undefined }));
    }
    await buildPanel();
    Log.add('info', IS_ELECT_PAGE
      ? '选课助手已就绪（检测到选课页面）。先用【搜索】找课，再把课程加入【抢课】队列。'
      : '选课助手已注入（当前不是选课页面，功能可能受限）。');
    const c = await checkSession();
    Log.add(c.ok ? 'info' : 'error', '会话状态: ' + c.msg);
    if (!c.ok) UI.flashSession();
  })();
})();
