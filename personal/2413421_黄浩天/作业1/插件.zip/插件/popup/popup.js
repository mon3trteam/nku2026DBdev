/* 南开选课助手 - 工具栏弹窗 */

const $ = (s) => document.querySelector(s);
const statusEl = $('#status');

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function sendToTab(tabId, msg) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        void chrome.runtime.lastError;
        resolve(resp || null);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

function renderState(resp) {
  if (!resp || !resp.ok) {
    statusEl.className = 'status err';
    statusEl.textContent = '✖ 当前页面未注入助手。请打开教务系统 (eamis.nankai.edu.cn) 页面后刷新。';
    $('#btn-stop').disabled = true;
    return;
  }
  if (resp.engineRunning) {
    statusEl.className = 'status busy';
    statusEl.textContent = `🚀 发包运行中 · 待发 ${resp.queueLen} 门 · 已发 ${resp.stats.attempt} 次，成功 ${resp.stats.success} 次`;
    $('#btn-stop').disabled = false;
  } else if (resp.scanning) {
    statusEl.className = 'status busy';
    statusEl.textContent = '🔍 正在扫描课程列表…';
    $('#btn-stop').disabled = true;
  } else {
    statusEl.className = 'status ok';
    statusEl.textContent = `● 空闲 · 队列待发 ${resp.queueLen} 门`;
    $('#btn-stop').disabled = true;
  }
}

async function refresh() {
  const tab = await getActiveTab();
  if (!tab || !tab.id || !/eamis\.nankai\.edu\.cn/.test(tab.url || '')) {
    renderState(null);
    return;
  }
  renderState(await sendToTab(tab.id, { type: 'popup-state' }));
}

$('#btn-panel').addEventListener('click', async () => {
  const tab = await getActiveTab();
  if (tab && tab.id) { await sendToTab(tab.id, { type: 'toggle-panel' }); window.close(); }
});
$('#btn-search').addEventListener('click', async () => {
  const tab = await getActiveTab();
  if (tab && tab.id) { await sendToTab(tab.id, { type: 'open-panel', tab: 'search' }); window.close(); }
});
$('#btn-grab').addEventListener('click', async () => {
  const tab = await getActiveTab();
  if (tab && tab.id) { await sendToTab(tab.id, { type: 'open-panel', tab: 'grab' }); window.close(); }
});
$('#btn-stop').addEventListener('click', async () => {
  const tab = await getActiveTab();
  if (tab && tab.id) {
    await sendToTab(tab.id, { type: 'stop-engine' });
    setTimeout(refresh, 400);
  }
});

refresh();
