/* 南开选课助手 - 后台 Service Worker
 * 职责：桌面通知、工具栏角标、快捷键转发。
 * 抢课发包逻辑全部在页面内的 content script 中完成（同源携带登录会话）。
 */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'ext-notify') {
    try {
      chrome.notifications.create(
        {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icons/icon128.png'),
          title: msg.title || '南开选课助手',
          message: msg.message || '',
          priority: 2,
        },
        () => void chrome.runtime.lastError
      );
    } catch (e) {
      /* 通知失败不影响主流程 */
    }
    sendResponse({ ok: true });
  }

  if (msg.type === 'badge') {
    try {
      chrome.action.setBadgeText({ text: msg.text || '', tabId: sender.tab && sender.tab.id });
      if (msg.color) chrome.action.setBadgeBackgroundColor({ color: msg.color, tabId: sender.tab && sender.tab.id });
    } catch (e) {
      /* 忽略 */
    }
    sendResponse({ ok: true });
  }

  return false; // 全部同步应答
});

// 快捷键：转发给当前标签页的 content script
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-panel') return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'toggle-panel' }, () => void chrome.runtime.lastError);
    }
  } catch (e) {
    /* 忽略 */
  }
});
